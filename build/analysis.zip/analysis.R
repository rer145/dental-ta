trim <- function (x) gsub("^\\s+|\\s+$", "", x)

args = commandArgs(trailingOnly=TRUE)
runtime_dir<-trim(args[1])	# path to folder of runtime
input_file<-trim(args[2])  # file of inputs to read
output_file<-trim(args[3])  # file to output data to


tooth.scores <- read.csv(input_file)
MFH <- read.csv(file.path(runtime_dir, "analysis", "MFH.csv"))
MFH2 <- read.csv(file.path(runtime_dir, "analysis", "MFH2.csv"))
MUS <- read.csv(file.path(runtime_dir, "analysis", "MUS.csv"))


get.age = function(id=1, lo=0.75, hi=25.75, left=0, right=25, def.int=0.1, put.points=F, put.L=0, put.R=20, drop=NA, retain=NA, Known.age=NA, teeths=rep(NA,13), lab=NA, anote='')
{
	#write('analysis complete', file=output_file, append=FALSE, sep='')
	
	tooths <- function(tt, teeth, integ)
	{
		# j is the index for tooth [1:13]
		# i is the score for the given tooth (2:17, as cusp initiation cannot be scored in paleoanth)
		
		cum = 0
		for (j in 1:13)
		{
			i = teeth[j]
			if (!is.na(i)) 
			{
				mu1 = MFH2[i,j]
				mu2 = MFH2[i+1,j]
				while (mu1 == mu2)
				{
					i = i + 1
					mu2 = MFH[i,j]
				}
				sto = max(pnorm(tt, mu1, 0.042 * log(10)) - pnorm(tt, mu2, 0.042 * log(10)), 1.e-200)
				cum = cum + log(sto)
			}
		}
		return (exp(cum) / integ)
	}
	
	tooths2 <- function(tt, teeth, integ, mu)
	{
		# j is the index for tooth [1:13]
		# i is the score for the given tooth (2:17, as cusp initiation cannot be scored in paleoanth)
		
		cum = 0
		for (j in 1:13)
		{
			i = teeth[j]
			if (!is.na(i))
			{
				mu1 = MFH2[i,j]
				mu2 = MFH2[i+1,j]
				while (mu1 == mu2)
				{
					i = i + 1
					mu2 = MFH2[i,j]
				}
				sto = max(pnorm(tt, mu1, 0.042 * log(10)) - pnorm(tt, mu2, 0.042 * log(10)), 1.e-200)
				cum = cum + log(sto)
			}
		}
		return (exp(cum) / integ * (tt-mu)^2)
	}
	
	tooths3 <- function(mu, i.tooth)
	{
		mu.tran = c(-Inf, MFH2[,i.tooth])
		sto = pnorm(mu, mu.tran, 0.042 * log(10), lower=F)
		toother = which.max(diff(sto)) - 1
		if (toother == 0) toother = 1
		return (toother)
	}
	
	if (!is.na(id)) 
		teeth = as.numeric(tooth.scores[id,-1])
	else
		teeth = teeths
		
	if (nchar(anote) > 0) anote = paste(', ', anote)
	write('Tooth scores before any potential dropped scores', file=output_file, append=FALSE, sep='')	# first write to file
	write(teeth, file=output_file, append=TRUE, sep='')

	N.drop = length(drop)
	for(i in 1:N.drop) teeth[drop[i]] = NA
	if (!is.na(retain[1]))
	{
		sto = rep(NA,13)
		N.retain = length(retain)
		for(i in 1:N.retain)
		{
			sto[retain[i]] = teeth[retain[i]]
		}
		teeth = sto
	}
	
	denom = integrate(Vectorize(tooths,"tt"), lower=log(0.75), upper=log(25.75), teeth=teeth, integ=1.0)$val
	mu = optimize(tooths, lower=log(0.75), upper=log(25.75), maximum=T, teeth=teeth, integ=denom)$max
	mus = rep(NA,13)
	
	for (i in 1:13)
	{
		if (!is.na(teeth[i]))
		{
			mus[i] = MUS[teeth[i],i]
		}
	}
	between = var(mus,na.rm=T)
	
	within=integrate(Vectorize(tooths2,"tt"),lower=log(lo),upper=log(hi),teeth=teeth,integ=denom,mu=mu)$val
	age=log(seq(0,25,def.int)+0.75)
	N=NROW(age)
	prob=0
	
	for(i in 1:N) prob[i]=tooths(age[i],teeth,denom)
	top=max(prob)
	top=max(top,dnorm(mu,mu,sqrt(within)))
	
	png(filename=file.path(output_dir, "temp", "plot1.png"), width=1400, height=1200, res=300, pointsize=7)
	if(!is.na(id))
	{
		plot(exp(age)-.75,prob,type='l',xlim=c(left,right),ylim=c(0,top),lwd=2,xlab='Age (years)',ylab='Density',main=paste(tooth.scores[id,1],anote),axes=F)
	}
	else
	{
		plot(exp(age)-.75,prob,type='l',xlim=c(left,right),ylim=c(0,top),lwd=2, xlab='Age (years)',ylab='Density',main=lab,axes=F)
	}
	
	box()
	axis(1)
	
	if(put.points==T)
	{
		age=log(seq(put.L,put.R,.05)+0.75)
		points(exp(age)-.75,dnorm(age,mu,sqrt(within)),pch=19)
	}
	else
	{
		lines(exp(age)-.75,dnorm(age,mu,sqrt(within)),lwd=2,lty=2)
	}
	age=log(seq(0,25,def.int)+0.75)
	
	if(!is.na(between)) lines(exp(age)-.75,dnorm(age,mu,sqrt(within+between)),lwd=2,lty=2)
	
	if(!is.na(Known.age)) lines(rep(Known.age,2),c(0,1000),lwd=2)
	
	abline(v=exp(mu)-0.75)
	text(exp(mu)-0.75,top,round(exp(mu)-0.75,4),pos=4)
	abline(v=exp(mu-(2*(within+between)^0.5))-0.75,lty=2,col='red')
	text(exp(mu-(2*(within+between)^0.5))-0.75,top-0.5,round(exp(mu-(2*(within+between)^0.5))-0.75,3),pos=2,cex=0.75)
	abline(v=exp(mu+(2*(within+between)^0.5))-0.75,lty=2,col='red')
	text(exp(mu+(2*(within+between)^0.5))-0.75,top-0.5,round(exp(mu+(2*(within+between)^0.5))-0.75,3),pos=4,cex=0.75)
	abline(v=exp(mu-(2*(within)^0.5))-0.75,lty=2,col='blue')
	abline(v=exp(mu+(2*(within)^0.5))-0.75,lty=2,col='blue')
	
	write(noquote(paste('Mean natural log conception-corrected age = ',mu)), file=output_file, append=TRUE, sep='\n')
	write(noquote(paste('Within-tooth variance  = ',within)), file=output_file, append=TRUE, sep='\n')
	write(noquote(paste('Between-tooth variance = ',between)), file=output_file, append=TRUE, sep='\n')
	write(noquote(paste('Lower limit of integration (straight scale) = ',lo)), file=output_file, append=TRUE, sep='\n')
	write(noquote(paste('Upper limit of integration (straight scale) = ',hi)), file=output_file, append=TRUE, sep='\n')
	
	if(!is.na(id)) (lab=as.vector(tooth.scores[id,1]))
	new.teeth=rep(NA,13)

	for(i in 1:13)
	{
		if(!is.na(teeth[i])) new.teeth[i]=tooths3(mu,i)
	}
	
	
	if(!is.na(new.teeth[1]))
	{
		if(new.teeth[1]==8) new.teeth[1]=teeth[1]
	}
	
	for(i in 4:5)
	{
		if(!is.na(new.teeth[i]))
		{
			if(new.teeth[i]<=8) new.teeth[i]=teeth[i]
		}
	}
	
	for(i in 6:7)
	{
		if(!is.na(new.teeth[i]))
		{
			if(new.teeth[i]<=8) new.teeth[i]=teeth[i]
		}
	}
	
	for(i in 8:10)
	{
		if(!is.na(new.teeth[i]))
		{
			if(new.teeth[i]==8) new.teeth[i]=teeth[i]
		}
	}
	
	obj=tooths(tt=mu,teeth=teeth,integ=1)
	nu=tooths(tt=mu,teeth=new.teeth,integ=1)

	write('Most likely scores given age (estimated after any potential drops)', file=output_file, append=TRUE, sep='\n')
	write(new.teeth, file=output_file, append=TRUE, sep='\n')
	write(obj, file=output_file, append=TRUE, sep='\n')
	write(nu, file=output_file, append=TRUE, sep='\n')

	for(i in 1:13)
	{
		new.teeth[i]=tooths3(mu,i)
	}
	
	if(!is.na(new.teeth[1]))
	{
		if(new.teeth[1]==8) new.teeth[1]=teeth[1]
	}
	
	for(i in 4:5)
	{
		if(!is.na(new.teeth[i]))
		{
			if(new.teeth[i]<=8) new.teeth[i]=teeth[i]
		}
	}
	
	for(i in 6:7)
	{
		if(!is.na(new.teeth[i]))
		{
			if(new.teeth[i]<=8) new.teeth[i]=teeth[i]
		}
	}
	
	for(i in 8:10)
	{
		if(!is.na(new.teeth[i]))
		{
			if(new.teeth[i]==8) new.teeth[i]=teeth[i]
		}
	}
	
	write(new.teeth, file=output_file, append=TRUE, sep='\n')
	write(obj/nu, file=output_file, append=TRUE, sep='\n')
	
	if(is.na(between)) return(list(lab=lab,mu=mu,within=within,between=between,p.seq=NA))
	
	return(list(lab=lab,mu=mu,within=within,between=between,p.seq=obj/nu))
}

get.age(1)